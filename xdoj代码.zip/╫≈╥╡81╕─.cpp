#include <stdio.h>
#include <string.h>

int function1(char ch[], char sp[]) {
	int i, j, k;
	for (i = 0; ch[i] != '\0'; i++) {
		for (j = i, k = 0; sp[k] != '\0' && ch[j] == sp[k]; j++, k++)
			;
		if (sp[k] == '\0') {
			return 1;
		}

	}
	return -1;
}

int function2(char ch[], char sp[]) {
	int i, j, k;
	for (i = 0; ch[i] != '\0'; i++) {
		for (j = i, k = 0; sp[k] != '\0' && ch[j] == sp[k] || ch[j] == sp[k] + 32 || ch[j] == sp[k] - 32; j++, k++)
			;
		if (sp[k] == '\0') {
			return 1;
		}
	}
	return -1;
}

int main() {
	char sdar[101];
	int n, m, a[100] = {0};
	gets(sdar);
	int cont = strlen(sdar);
	scanf("%d", &n);
	scanf("%d", &m);
	char lot[100][101];
	for (int i = 0; i < m; i++) {
		scanf("%s", &lot[i]);
	}
	for (int w = 0; w < m; w++) {
		if (n == 1) {
			a[w] = function1(lot[w], sdar);
		}
		if (n == 0) {
			a[w] = function2(lot[w], sdar);
		}
	}
	for (int i = 0; i < m; i++) {
		if (a[i] == 1) {
			printf("%s\n", lot[i]);
		}
	}
	return 0;
}