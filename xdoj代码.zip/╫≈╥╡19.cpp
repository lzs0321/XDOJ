#include <stdio.h>

int main() {
	float a, b, c, v;
	scanf("%f %f %f", &a, &b, &c);
	v = a * b * c;
	printf("%-.3f", v);
	return 0;

}