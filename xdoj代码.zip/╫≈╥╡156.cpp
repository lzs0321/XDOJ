#include <stdio.h>

int main() {
	int i, sum = 0;
	for ( i = 100; i < 500; i++) {
		if (i % 7 == 0 || i % 11 == 0) {
			if (i % 7 == 0 && i % 11 != 0 || i % 7 != 0 && i % 11 == 0) {
				sum++;
			}

		}
	}
	printf("%d", sum);
	return 0;
}
