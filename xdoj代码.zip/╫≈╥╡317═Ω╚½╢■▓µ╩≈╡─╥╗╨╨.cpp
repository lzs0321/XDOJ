#include <stdio.h>

int power(int n) {
	int count = 1;
	if (n == 0)
		return 1;
	for (int i = 1; i <= n; i++)
		count = count * 2;
	return count;
}

int main() {
	int n, d, flog;
	int i, j;
	while (1) {
		int tree[500] = {0};
		scanf("%d", &n);
		if (n == 0)
			return 1;
		for (i = 1; i <= n; i++)
			scanf("%d", &tree[i]);
		scanf("%d", &d);

		flog = 1;
		//��ʵ�������2^n��2^n-1֮�������
		for (i = power(d - 1); i < power(d) && i <= n; i++) {
			flog = 0;
			printf("%d ", tree[i]);
		}
		if (flog)
			printf("EMPTY");
		printf("\n");
	}
}