#include <stdio.h>

double function(int n) {
	if (n == 1)
		return 1;
	else if (n > 1)
		return 1 / (1 + function(n - 1));
}

int main() {
	int n;
	double y;
	scanf("%d", &n);
	y = function(n);
	printf("%.6lf", y);
	return 0;
}