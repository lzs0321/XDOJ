#include <stdio.h>

int main(void) {
	int n;
	int i, j, flag;
	scanf("%d", &n);
	int array[n][n];
	int num[n * n], index;
	for (i = 0; i < n; i++) {
		for (j = 0; j < n; j++) {
			scanf("%d", &array[i][j]);
		}
	}
	index = 0;
	num[index++] = array[0][0];
	flag = 0;
	i = j = 0;
	while (i < n - 1 && j < n - 1) {
		if (flag % 2 == 0) {
			j++;
			flag++;
			while (j >= 0) {
				num[index++] = array[i][j];
				i++;
				j--;
			}
			i--;
			j++;
		} else {
			i++;
			flag++;
			while (i >= 0) {
				num[index++] = array[i][j];
				i--;
				j++;
			}
			i++;
			j--;
		}
	}
	while (i < n && j < n) {
		if (flag % 2 == 0) {
			i++;
			flag++;
			while (i < n) {
				num[index++] = array[i][j];
				i++;
				j--;
			}
			i--;
			j++;
		} else {
			j++;
			flag++;
			while (j < n) {
				num[index++] = array[i][j];
				i--;
				j++;
			}
			i++;
			j--;
		}
	}
	for (i = 0; i < index; i++) {
		printf("%d ", num[i]);
	}
	return 0;
}
