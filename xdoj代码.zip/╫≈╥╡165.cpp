#include <stdio.h>

int main() {
	int N, a[80];
	scanf("%d", &N);
	for (int i = 0; i < N; i++) {
		scanf("%d", &a[i]);
	}
	int max = 0, sp = 0;
	for (int i = 0; i < N; i++) {
		if (max - a[i] < 0) {
			max = a[i];
			sp = i;
		}
	}
	printf("%d %d %d", N, max, sp);
	return 0;
}