#include <stdio.h>
#define MAX 35

int Matrix[MAX][MAX];
int vset[MAX] = {0};
int vex[MAX];
int sum, n, m;
int dfs (int x);

int main (void) {
	int i, j, count = 0, u, v, w = 0, t;
	scanf ("%d %d", &n, &m);
	while (m--) {
		scanf ("%d %d", &u, &v);
		Matrix[u][v] = 1;
		Matrix[v][u] = 1;
	}
	/*for (i = 1; i <= n; i++) {
	    for (j = 1; j<= n; j++) {
	        printf ("%d ", Matrix[i][j]);
	    }
	    printf ("\n");
	}*/
	/*for (i = 1; i <= n; i++) {
	    printf ("%d",vset[i]);
	}*/
	for (i = 1; i <= n; i++) {
		if (vset[i] == 0) {
			dfs (i);
			count++;
		}
	}

	printf ("%d\n", count);

	for (i = 1; i <= n; i++) {
		vset[i] = 0;
	}

	/*for (i = 1; i <= n; i++) {
	    printf ("%d",vset[i]);
	}*/

	for (i = 1; i <= n; i++) {
		if (vset[i] == 0) {
			sum = 1;
			dfs (i);
			vex[w] = sum;
			w++;
			//printf ("%d", sum);
		}
	}

	for (i = 0; i < w; i++) {
		for (j = 0; j < w - 1 - i; j++) {
			if (vex[j] > vex[j + 1]) {
				t = vex[j];
				vex[j] = vex[j + 1];
				vex[j + 1] = t;
			}
		}
	}

	for (i = 0; i < w; i++) {
		printf ("%d ", vex[i]);
	}
	return 0;
}

int dfs (int x) {
	vset[x] = 1;
	int i;
	for (i = 1; i <= n; i++) {
		if (vset[i] == 0 && Matrix[i][x] == 1) {
			sum++;
			dfs (i);
		}
	}
	return 0;
}
