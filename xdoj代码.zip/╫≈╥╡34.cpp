#include <stdio.h>
#include <math.h>

int function(int a, int b) {
	int sum = 0;
	for (int i = a; i <= b; i++) {
		if (i < 100) {
			continue;
		}
		int z = 0, q = 1;
		int t = i;
		int k = i;
		while (t > 9) {
			t /= 10;
			q++;
		}
		while (k != 0) {
			int o = k % 10;
			z += pow(o, q);
			k /= 10;
		}
		if (z == i) {
			sum++;
		}
	}
	return sum;
}

int main() {
	int m, n;
	scanf("%d %d", &m, &n);
	if (m > n) {
		int c = m;
		m = n, n = c;
	}
	int l = function(m, n);
	printf("%d", l);

	return 0;
}