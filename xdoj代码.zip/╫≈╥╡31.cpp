#include <stdio.h>

int main() {
	int a, b, c, d, t;
	scanf("%d %d", &a, &b);
	c = a;
	d = b;
	while (b != 0) {
		t = a % b;
		a = b;
		b = t;
	}
	printf("%d", a);
	return 0;
}