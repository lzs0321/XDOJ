#include <stdio.h>

int fib(int n) {
	int z;
	if (n == 0)
		z = 7;
	else if (n == 1)
		z = 11;
	else
		z = fib(n - 1) + fib(n - 2);
	return z;
}

int main() {
	int f, n;
	scanf("%d", &n);
	f = fib(n);
	printf("%d", f);
	return 0;
}