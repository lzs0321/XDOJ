#include <stdio.h>

int main() {
	int n, sum = 0;
	scanf("%d", &n);
	int a[11];
	for (int i = 0; n != 0; i++) {
		a[i] = n % 10;
		n /= 10;
		sum++;
	}
	int z = 0;
	for (int j = 0; j < (int)(sum / 2); j++) {
		if (a[j] != a[sum - j - 1]) {
			z = 1;
			break;
		}
	}
	if (z == 1) {
		printf("no");
	} else if (z == 0) {
		int mum = 0;
		for (int i = 0; i < sum; i++) {
			mum += a[i];
		}
		printf("%d", mum);
	}
	return 0;
}