#include <stdio.h>
#include <string.h>
#include <malloc.h>

typedef struct LinkList {
	int h;
	struct LinkList *next;
} LinkList;

LinkList *createList(int n) {
	int h, i;
	LinkList *head, *r, *s;
	head = (LinkList *)malloc(sizeof(LinkList));//����ͷ���
	r = head;
	for (i = 0; i < n; i++) {
		scanf("%d", &h);
		s = (LinkList *)malloc(sizeof(LinkList));
		s->h = h;
		r->next = s;
		r = s;
	}
	r->next = NULL;
	return head;
}

void ins(LinkList *head, int m) {//���Ҹ߶ȣ�ȷ��λ��
	LinkList *s, *p = head;
	s = (LinkList *)malloc(sizeof(LinkList));
	s->h = m;
	while (p->next != NULL && p->next->h < m)
		p = p->next;
	if (p->next == NULL) {
		p->next = s;
		s->next = NULL;
	} else {
		s->next = p->next;
		p->next = s;
	}
}

void printLinkList(LinkList *head) {
	LinkList *r = head->next;
	while (r != NULL) {
		printf("%d", r->h);
		if (r->next != NULL)
			printf(" ");
		r = r->next;
	}
}

int main() {
	int n, m;
	LinkList *L;
	scanf("%d %d", &n, &m);
	L = createList(n);
	ins(L, m);
	printLinkList(L);
	return 0;
}
