#include <stdio.h>

int main() {
	int n;
	scanf("%d", &n);
	int a[100], b[100] = {0}, c[100] = {0};
	for (int i = 0; i < n; i++) {
		scanf("%d", &a[i]);
		int m = a[i];
		while (m != 0) {
			c[i] += m % 10;
			m /= 10;
			b[i] ++;
		}
	}
	for (int k = 1; k < n; k++) {
		if (c[0] <= c[k]) {
			if (c[0] == c[k]) {
				if (a[0] < a[k]) {

					a[0] = a[k];
					b[0] = b[k];
					c[0] = c[k];
				}
			} else if (c[0] < c[k]) {

				a[0] = a[k];
				b[0] = b[k];
				c[0] = c[k];

			}
		}
	}

	printf("%d", a[0]);
	return 0;
}