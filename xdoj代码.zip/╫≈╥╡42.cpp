#include <stdio.h>

int main() {
	int a, b, c, d;
	scanf("%d %d", &a, &b);
	if (a % b <= 0) {
		printf("yes");
	} else {
		c = a / b;
		d = a % b;
		printf("%d %d", c, d);
	}
	return 0;
}