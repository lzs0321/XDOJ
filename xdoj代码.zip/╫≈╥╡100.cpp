#include <stdio.h>

int main() {
	int a, b, c, l, t, m;
	scanf("%d %d %d", &a, &b, &c);
	int max = a;
	if (a < b) {
		max = b;
		if (b < c) {
			max = c;
			t = b;
			m = a;
		} else {
			if (a > c) {
				t = a;
				m = c;
			} else {
				t = c;
				m = a;
			}
		}

	} else {
		if (a > c) {
			if (b > c) {
				t = b;
				m = c;
			} else {
				t = c;
				m = b;
			}
		} else {
			max = c;
			t = a;
			m = b;
		}
	}
	if (m + t > max ) {
		printf("%d", a + b + c);
	} else {
		printf("No");
	}
	return 0;
}