#include <stdio.h>

int main() {
	printf("C programming language is useful!\n");
	printf("I like it very much.");
	return 0;
}