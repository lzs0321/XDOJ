#include <stdio.h>
#include <string.h>

int main() {
	char string[101];
	gets(string);
	char *p;
	p = string;
	int length = strlen(string);
	int max = 0, count = 0;
	for (p = string; p < string + length; p++) {
		if (*p != ' ' && *p != '.') {
			count++;
			if (count > max) {
				max = count;
			}
		} else {
			count = 0;
		}

	}
	printf("%d", max);



	return 0;
}