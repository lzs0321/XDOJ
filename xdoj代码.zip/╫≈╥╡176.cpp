#include <stdio.h>

int main() {
	int n, i, j, s, b;
	scanf("%d", &n);
	int a[n];
	for (i = 0; i < n; i++)
		scanf("%d", &a[i]);

	for (i = 0; i < n; i++) {
		for (j = 0, s = 0, b = 0; j < n; j++) {
			if (a[i] - a[j] > 0)
				s++;
			else if (a[i] - a[j] < 0)
				b++;
		}
		if (s == b) {
			printf("%d", a[i]);
			break;
		}
		if (i == n - 1)
			printf("-1");
	}

	return 0;
}

