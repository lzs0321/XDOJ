#include <stdio.h>
#include <stdlib.h>
#define MAXSTRLEN 200

int main() {
	char a[MAXSTRLEN];
	int i, n;
	int key = 1;
	scanf("%d", &n);
	scanf("%s", a);

	for (i = 0; i < (n / 2); i++) {
		if (a[i] != a[n - 1 - i]) {
			printf("NO");
			return 0;
		}
	}

	printf("YES");
	return 0;
}