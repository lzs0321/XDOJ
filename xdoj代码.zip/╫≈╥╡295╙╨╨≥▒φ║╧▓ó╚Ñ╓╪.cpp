#include <stdio.h>
#include <stdlib.h>

typedef struct list {
	int data;
	struct list *next;
} node, *List;

//ͷ�巨���������������������Ҳ��ͷ�壬˳��ͻ���������
void Create(List *head, int n) {
	List p;
	int i;
	*head = (List)malloc(sizeof(node));
	(*head)->next = NULL;
	for (i = 0; i < n; i++) {
		p = (List)malloc(sizeof(node));
		scanf("%d", &p->data);
		p->next = (*head)->next;
		(*head)->next = p;
	}
}

List Merge(List L1, List L2) {
	List head, p1, p2;
	List node;
	head = (List)malloc(sizeof(node));
	head->next = NULL;
	p1 = L1->next;
	p2 = L2->next;
	//������ȥ�أ�˭����˭���ȥ�����ߣ�һ�����һ��������
	while ((p1 != NULL) && (p2 != NULL)) {
		if (p1->data < p2->data) {
			node = (List)malloc(sizeof(node));
			node->data = p2->data;
			node->next = head->next;
			head->next = node;
			p2 = p2->next;
		} else if (p1->data > p2->data) {
			node = (List)malloc(sizeof(node));
			node->data = p1->data;
			node->next = head->next;
			head->next = node;
			p1 = p1->next;
		} else {
			node = (List)malloc(sizeof(node));
			node->data = p1->data;
			node->next = head->next;
			head->next = node;
			p1 = p1->next;
			p2 = p2->next;
		}
	}
	//�����ʣ�µľ�ֱ�Ӵ��ȥ�ͺ�
	while (p1 != NULL) {
		node = (List)malloc(sizeof(node));
		node->data = p1->data;
		node->next = head->next;
		head->next = node;
		p1 = p1->next;
	}
	while (p2 != NULL) {
		node = (List)malloc(sizeof(node));
		node->data = p2->data;
		node->next = head->next;
		head->next = node;
		p2 = p2->next;
	}
	return head;
}

void Print(List head) {
	List p = head->next;
	while (p != NULL) {
		printf("%d ", p->data);
		p = p->next;
	}
}

int main() {
	int n1, n2;
	List L1, L2, L3;
	scanf("%d %d", &n1, &n2);
	Create(&L1, n1);
	Create(&L2, n2);
	L3 = Merge(L1, L2);
	Print(L3);
	return 0;
}