#include <stdio.h>

int main() {
	int a[10], b[9];
	for (int i = 0; i < 10; i++) {
		scanf("%d", &a[i]);
	}
	for (int i = 0; i < 9; i++) {
		int c = a[i + 1] / a[i];
		b[i] = c;
	}
	for (int i = 0; i < 9; i++) {
		printf("%d ", b[i]);
	}
	return 0;
}