#include <stdio.h>

int main() {
	double pi = 3.14;
	double r, v;
	scanf("%lf", &r);
	v = (4.0 / 3) * pi * r * r * r;
	printf("%.2f", v);

	return 0;
}