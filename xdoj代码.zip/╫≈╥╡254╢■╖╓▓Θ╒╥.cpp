#include <stdio.h>
#include <math.h>


int main() {  // �۰����
	int n, check;
	scanf("%d %d", &n, &check); //������ҵ���
	int arr[100] = {0};
	for (int i = 0; i < n; i++) {
		scanf("%d", &arr[i]);
	}
	int index[100] = {0};
	int left = 0, Index = 0;
	int sz = n;
	int right = sz - 1;
	while (left <= right) {    //����ѭ��������
		int mid = (left + right) / 2;
		if (arr[mid] > check) {
			index[Index] = arr[mid];
			right = mid - 1;
			Index++;
		} else if (arr[mid] < check) {
			index[Index] = arr[mid];
			left = mid + 1;
			Index++;
		} else {
			index[Index] = arr[mid];
			Index++;
			for (int k = 0; k < Index; k++) {
				printf("%d ", index[k]);
			}
			printf("\n");
			printf("Eureka!");
			break;
		}
	}
	if (left > right) {
		for (int k = 0; k < Index; k++) {
			printf("%d ", index[k]);
		}
		printf("\n");
		printf("Search failed!");
	}
	return 0;
}
