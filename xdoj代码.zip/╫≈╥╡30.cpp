#include <stdio.h>
#include <math.h>

int main() {
	int n, a, b;
	int sum;
	scanf("%d %d", &a, &b);
	for (n = a; n <= b; n++) {
		sum = 0;
		for (int j = 1; j < n; j++) {
			if (n % j == 0) {
				sum += j;
			}
		}
		if (sum == n) {
			printf("%d\n", n);
		}
	}


	return 0;
}