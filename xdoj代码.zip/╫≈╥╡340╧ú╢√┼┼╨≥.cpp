#include <stdio.h>

int main() {
	int n, m, i, j, k;
	scanf("%d ", &n);
	int a[n];
	int key = n / 2;
	for (i = 0; i < n; i++) {
		scanf("%d", &a[i]);
	}
	int tmp;
	for (i = 0; i < n / 2; i++) {
		if (a[i] > a[i + key]) {
			tmp = a[i];
			a[i] = a[i + key];
			a[i + key] = tmp;
		}
	}

	for (i = 0; i < n; i++) {
		printf("%d ", a[i]);
	}
	return 0;
}
