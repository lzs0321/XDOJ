#include <stdio.h>
#include <string.h>

int sort(int *a, int m) {

	int i, j, t;
	for (i = 0; i < m; i++)

		for (j = i; j < m; j++) {
			if (*(a + j) < * (a + i)) {
				t = *(a + j);
				*(a + j) = a[i];
				*(a + i) = t;
			}
		}
	return *a;
}

int main() {
	int n;
	int i = 0, j = 0, k = 0;
	int a[20], b[20], c[20];
	scanf("%d", &n);

	for (i = 0; i < n; i++) {
		scanf("%d", &a[i]);
	}

	for (i = 0; i < n; i++) {
		if (a[i] % 2 == 1)
			b[j++] = a[i];
		else
			c[k++] = a[i];
	}
	sort(b, j);

	for (i = 0; i < j; i++) {
		printf("%d ", b[i]);
	}
	printf("   ");

	sort(c, k);
	for (i = 0; i < k; i++) {
		printf("%d ", c[i]);
	}

	return 0;
}
