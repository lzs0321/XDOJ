#include <stdio.h>

int main() {
	int n, m, t;
	scanf("%d", &n);
	t = n;
	for (m = 1; t > 9; m++) {
		t /= 10;
	}
	int b[100];
	for (int i = 0; i < m; i++) {
		b[i] = n % 10;
		n /= 10;
	}
	int maxn = b[0];
	for (int j = 0; j < m; j++) {
		if (b[j] - maxn >= 0) {
			maxn = b[j];
		}
	}
	int minn = b[0];
	for (int j = 0; j < m; j++) {
		if (b[j] - minn <= 0) {
			minn = b[j];
		}
	}
	printf("%d %d %d", m, maxn, minn);
	return 0;
}