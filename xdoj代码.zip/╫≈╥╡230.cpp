#include <stdio.h>
#include <string.h>
#include <math.h>

int fun(int m) {
	int y[1000];
	int i, j, k, count = 0;
	int l = 0;
	for (i = 2; i <= m; i++) {
		k = (int)sqrt((double)i);
		for (j = 2; j <= k; j++) {
			if (i % j == 0)
				break;
		}
		if (j > k) {
			count++;
			y[l] = i;
			l++;
		}
	}
	printf("%d\n", count);
	for (l = 0; l < count; l++) {
		printf("%d ", y[l]);
	}
	return count;
}

int main() {
	int n;
	scanf("%d", &n);
	fun(n);
	return 0;
}

