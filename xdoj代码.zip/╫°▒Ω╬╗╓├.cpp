#include <stdio.h>

int main() {
	int r, a;
	scanf("%d %d", &r, &a);
	if (r < 0) {
		printf("-1");
	} else {
		if (r == 0) {
			printf("Origin");
		}
		if (r > 0) {
			if (a == 0 || (a % 180 == 0)) {
				printf("X-axis");
			}
			if ((a % 90 == 0) && (a / 90) % 2 != 0) {
				printf("Y-axis");
			}
			if ((a > 0 && a < 90) || (a > -360 && a < -270)) {
				printf("1st Quadrant");
			}
			if ((a > 90 && a < 180) || (a > -270 && a < -180)) {
				printf("2st Quadrant");
			}
			if ((a > 180 && a < 270) || (a > -180 && a < -90)) {
				printf("3st Quadrant");
			}
			if ((a > 270 && a < 360) || (a > -90 && a < 0)) {
				printf("4st Quadrant");
			}
		}
	}
	return 0;
}