#include <stdio.h>

int main() {
	int n, m, i, j;
	int a[30][30];
	int b[30][30];
	scanf("%d %d", &n, &m);
	for (i = 0; i < n; i++) {
		for (j = 0; j < m; j++) {
			scanf("%d", &a[i][j]);
		}
	}
	for (i = 0; i < n; i++) {
		for (j = 0; j < m - 2; j++) {
			if (a[i][j] == a[i][j + 1] && a[i][j] == a[i][j + 2]) {
				b[i][j] = b[i][j + 1] = b[i][j + 2] = 1;
			}
		}
	}
	for (j = 0; j < m; j++) {
		for (i = 0; i < n - 2; i++) {
			if (a[i][j] == a[i + 1][j] && a[i][j] == a[i + 2][j]) {
				b[i][j] = b[i + 1][j] = b[i + 2][j] = 1;
			}
		}
	}
	for (i = 0; i < n; i++) {
		for (j = 0; j < m; j++) {
			if (b[i][j] == 1) {
				a[i][j] = 0;
			}
		}
	}
	for (i = 0; i < n; i++) {
		for (j = 0; j < m; j++) {
			if (j == 0)
				printf("%d", a[i][j]);
			else
				printf(" %d", a[i][j]);
		}
		printf("\n");
	}
	return 0;
}