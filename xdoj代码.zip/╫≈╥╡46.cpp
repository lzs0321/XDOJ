#include <stdio.h>

int main() {
	int n;
	scanf("%d\n", &n);
	int a[1000];
	for (int i = 0; i < n ; i++) {
		scanf("%d", &a[i]);
	}
	int sum = 0;
	for (int i = 0; i < n - 2; i++) {
		if (a[i + 1] > a[i] && a[i + 1] > a[i + 2] || a[i + 1] < a[i] && a[i + 1] < a[i + 2]) {
			sum++;
		}
	}
	printf("%d", sum);
	return 0;
}