#include <stdio.h>

int main(void) {
	char a[14];
	scanf("%s", &a);
	int sum = 0, j = 0;
	for (int i = 0; i < 12; i++) {
		if (a[i] == '-') {
			continue;
		}
		j++;
		sum += (a[i] - '0') * j;
	}
	int l = sum % 11;
	if ((l == 10 && a[12] == 'X') || l == (a[12] - '0')) {
		printf("Right");
	} else {
		if (l == 10) {
			a[12] = 'X';
		} else
			a[12] = 48 + l;
		printf("%s", a);
	}
}
