#include <stdio.h>

int main() {
	int i, j, n, state, count = 0, matrix[500][500];
	scanf("%d", &n);
	for (i = 0; i < n; i++)
		for (j = 0; j < n; j++)
			scanf("%d", &matrix[i][j]);

	i = 0;
	j = 0;
	state = 1; //1:����  2:����  3:������  4:������
	while (count < n * n) {
		switch (state) {
			case 1:
				printf("%d ", matrix[i][j++]); //1:����
				if (i == 0)
					state = 3;
				else if (i == n - 1)
					state = 4;
				break;
			case 2:
				printf("%d ", matrix[i++][j]); //2:����
				if (j == 0)
					state = 4;
				else if (j == n - 1)
					state = 3;
				break;
			case 3:
				printf("%d ", matrix[i++][j--]); //3:������
				if (j == 0)
					state = 2;
				if (i == n - 1)
					state = 1;
				break;
			case 4:
				printf("%d ", matrix[i--][j++]); //4:������
				if (i == 0)
					state = 1;
				if (j == n - 1)
					state = 2;
		}
		count++;
	}
	return 0;
}
