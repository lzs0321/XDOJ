#include <stdio.h>

int main() {
	int array[10] = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
	int b[10];
	for (int i = 0; i < 10; i++) {
		b[i] = array[i];
	}
	int p;
	scanf("%d", &p);
	for (int i = 0; i < 10; i++) {
		if ((i + p + 1) <= 9) {
			array[i] = b[i + p + 1];
		}
		if ((i + p + 1) > 9) {
			array[i] = b[p + i + 1 - 10];
		}
	}
	for (int i = 0; i < 10; i++) {
		printf("%d ", array[i]);
	}
	return 0;
}