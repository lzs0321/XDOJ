#include <stdio.h>
#include <string.h>

int main() {
	struct student {
		char num[21];
		int sum;
		int dan;
	};
	struct student s[200], temp;
	int m, n, i, j, t;
	scanf("%d%d", &m, &n);
	for (i = 0; i < m; i++)
		scanf("%s%d%d", s[i].num, &s[i].sum, &s[i].dan);
	printf("\n");
	for (i = 0; i < m - 1; i++)
		for (j = 0; j < m - 1 - i; j++) {
			if (s[j].sum < s[j + 1].sum) {
				temp = s[j + 1];
				s[j + 1] = s[j];
				s[j] = temp;
			} else if (s[j].sum == s[j + 1].sum) {
				if (s[j].dan < s[j + 1].dan) {
					temp = s[j + 1];
					s[j + 1] = s[j];
					s[j] = temp;

				} else if (s[j].dan == s[j + 1].dan) {
					t = strcmp(s[j].num, s[j + 1].num);
					if (t > 0) {
						temp = s[j + 1];
						s[j + 1] = s[j];
						s[j] = temp;
					}

				}
			}
		}

	for (i = 0; i < n; i++)
		printf("%s %d %d\n", s[i].num, s[i].sum, s[i].dan);
	return 0;
}
