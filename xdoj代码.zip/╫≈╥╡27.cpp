#include <stdio.h>

int main() {
	double a;
	double p;
	scanf("%lf", &a);
	if (a <= 110.00) {
		p = a * 0.50;
	} else if (a > 110.00 && a <= 210.00) {
		p = 110 * 0.50 + (a - 110.00) * 0.55;
	} else {
		p = 110 * 0.50 + 100 * 0.55 + (a - 210.00) * 0.70;
	}
	printf("%.2f", p);
	return 0;
}