#include <stdio.h>
#include <string.h>

int main() {
	void wd_sort(char (*str)[20], int n);
	char str[10][20];
	int n, i;
	scanf("%d", &n);
	for (i = 0; i < n; i++) {
		scanf("%s", &str[i]);
	}
	wd_sort(str, n);
	for (i = 0; i < n; i++) {
		printf("%s\n", str[i]);
	}
	return 0;
}

void wd_sort(char (*str)[20], int n) {
	int j, i, k;
	char temp[20];
	for (i = 0; i < n - 1; i++) {
		k = i;
		for (j = i + 1; j < n; j++) {
			if (strcmp(*(str + k), *(str + j)) > 0)
				k = j;
		}
		if (k != i) {
			strcpy(temp, *(str + i));
			strcpy(*(str + i), *(str + k));
			strcpy(*(str + k), temp);

		}
	}
}
