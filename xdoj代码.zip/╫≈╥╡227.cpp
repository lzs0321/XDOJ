#include <stdio.h>
#include <string.h>

int fun(char b[]) {
	int count = 0;
	int n = strlen(b);
	for (int i = 0; i <= n; i++) {
		if (b[i] >= 'a' && b[i] <= 'z' || b[i] >= 'A' && b[i] <= 'Z') {
			count++;
		}
	}
	return count;
}

int main() {
	int count = 0;
	char a[100];
	scanf("%s", a);
	int l = fun(a);
	printf("%d", l);
	return 0;
}