#include <stdio.h>

int main() {
	int a, b, c, d, e, f, g, h, i, j, k, l;
	scanf("%d", &a);
	b = a / 100;
	c = a % 100;
	d = c / 50;
	e = c % 50;
	f = e / 20;
	g = e % 20;
	h = g / 10;
	i = g % 10;
	j = i / 5;
	k = i % 5;
	l = k;
	printf("%d %d %d %d %d %d", b, d, f, h, j, l);
	return 0;

}