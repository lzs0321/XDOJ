#include <stdio.h>

int main() {
	int x, y;
	int i = 0;
	int check[100] = {0};
	while (1) {
		scanf("%d %d", &x, &y);
		if (x == 0 && y == 0)
			break;
		while (1) {
			if (x == y) {
				check[i] = x;
				break;
			} else if (x > y)
				x = x / 2;
			else
				y = y / 2; //int�λ��Զ�ȥ��
		}
		i++;
	}
	for (int j = 0; j < i; j++) {
		printf("%d\n", check[j]);

	}
	return 0;
}
