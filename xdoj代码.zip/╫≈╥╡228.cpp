#include <stdio.h>
#include <string.h>

char fun(char s[]) {
	int n, i;
	n = strlen(s);
	for (i = 0; i < n; i++) {
		if (i == 0 || i % 2 == 0 )
			printf("%c", s[i]);
	}
	return s[100];
}

int main() {
	char s[100];
	gets(s);
	fun(s);
	return 0;
}