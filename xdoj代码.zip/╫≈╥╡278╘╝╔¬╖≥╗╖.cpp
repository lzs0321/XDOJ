#include <stdio.h>
#include <stdlib.h>
#include <malloc.h>

typedef struct LinkList {
	int key;
	int steps;
	struct LinkList *next;
} LinkList;


//������ѭ������
LinkList *createLinkList(int n) {
	LinkList *L = NULL, *p; //����β���
	for (int i = 0; i < n; i++) {
		p = (LinkList *)malloc(sizeof(LinkList));
		if (!L) {
			p->steps = i + 1;
			scanf("%d", &p->key);
			p->next = L;
			p->next = p;
			L = p;

		} else {
			p->steps = i + 1;
			scanf("%d", &p->key);
			p->next = L->next;
			L->next = p;
			L = p;
		}

	}

	return L;

}

void printfLinkList(LinkList *L, int n, int m) {
	int i = 0;
	LinkList *p;
	p = NULL;
	while (n) {
		i = (i + 1) % m;
		if (i) {
			L = L->next;
		} else {
			p = L->next;
			L->next = p->next;
			printf("%d ", p->steps);
			m = p->key;
			free(p);
			n--;
			i = 0;
		}

	}

}




int main() {
	int num, m;
	scanf("%d %d", &num, &m);
	LinkList *L;
	L = createLinkList(num);
	printfLinkList(L, num, m);
	return 0;

}


