#include <stdio.h>
#include <math.h>

int main() {
	int n;
	scanf("%d", &n);
	int b[30];
	for (int i = 0; i < n; i++) {
		scanf("%d", &b[i]);
	}
	int maxn = fabs(b[1] - b[0]);
	for (int j = 1; j < n; j++) {
		if (fabs(b[j] - b[j - 1]) >= maxn) {
			maxn = fabs(b[j] - b[j - 1]);
		}
	}
	printf("%d", maxn);
	return 0;
}