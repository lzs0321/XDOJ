#include <iostream>
#include <string.h>
#include <algorithm>
using namespace std;

typedef struct student {
	char name[20];
	int age, score;
} student;

student s[105];

bool compare(student s1, student s2) {
	if (s1.score != s2.score)
		return s1.score > s2.score;
	else if (strcmp(s1.name, s2.name) != 0)
		return strcmp(s1.name, s2.name) < 0;
	else
		return s1.age < s2.age;
}

int main() {
	int n;
	cin >> n;
	for (int i = 0; i < n; ++i) {
		cin >> s[i].name >> s[i].age >> s[i].score;
	}
	sort(s, s + n, compare);
	for (int i = 0; i < n; ++i) {
		cout << s[i].name << ' ' << s[i].age << ' ' << s[i].score << endl;
	}
	return 0;
}
