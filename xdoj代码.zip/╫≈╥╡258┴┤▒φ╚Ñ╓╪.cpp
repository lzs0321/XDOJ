#include <stdio.h>
#include <stdlib.h>
#define MAX 100

//������ṹ��
typedef struct Node {
	int self_adr;
	int next_adr;
	int key;
	struct Node *next = NULL;
} Node;

//��ʼ��
Node *InitList() {
	Node *head = (Node *)malloc(sizeof(Node));
	head->next = NULL;
	return head;
}

//Ѱ�ҵ�ǰ���q��ֱ��ǰ��
Node *Search(Node *head, Node *q) {
	Node *p = head->next;
	while (p->next != q) {
		p = p->next;
	}
	return p;
}

//��ǰ��������
int sum_length(Node *head) {
	Node *p = head->next;
	int length, count = 0;
	while (p) {
		count++;
		p = p->next;
	}
	length = count;
	return length;
}

int main() {
	int n, first_adr;
	int i, j, length;
	Node NodeList[MAX];
	Node temp;
	Node *head, *p, *q;

	head = InitList();
	q = head;

	scanf("%d%d", &first_adr, &n);

	for (i = 0; i < n; i++) {
		scanf("%d%d%d", &NodeList[i].self_adr, &NodeList[i].key, &NodeList[i].next_adr);
	}
	//��������ǰ���ַ�Խ������
	for (i = 0; i < n; i++) {
		for (j = i; j < n; j++) {
			if (NodeList[j].self_adr == first_adr) {
				temp = NodeList[i];
				NodeList[i] = NodeList[j];
				NodeList[j] = temp;
				first_adr = NodeList[i].next_adr;
				break;
			}
		}
	}
	//����������Щ�������
	for (i = 0; i < n; i++) {
		p = (Node *)malloc(sizeof(Node));
		p = &NodeList[i];
		p->next = NULL;
		q->next = p;
		q = q->next;
	}

	q = head;
	p = q->next;

	while (p) {
		q = p->next;

		while (q) {
			if (q->key == p->key || q->key == -(p->key)) {
				if (q->next == NULL) { //��ʱΪ�������һ�����
					Node *s = Search(head, q);
					s->next_adr = -1;
					s->next = NULL;
				} else {
					Node *s = Search(head, q);
					s->next_adr = q->next->self_adr;
					s->next = q->next;
				}
			}
			q = q->next;
		}
		p = p->next;
	}

	q = head;
	length = sum_length(q);
	printf("%d\n", length); //��ӡ������
	//��ӡ���
	while (q->next) {
		p = q->next;
		if (p->next_adr == -1)
			printf("%05d %d %d\n", p->self_adr, p->key, p->next_adr);
		else
			printf("%05d %d %05d\n", p->self_adr, p->key, p->next_adr);
		q = q->next;
	}


	return 0;
}
