#include <stdio.h>

int main() {
	int n, i, a[1000];
	int sum = 0;
	scanf("%d\n", &n);
	for (i = 0; i < n; i++) {
		scanf("%d", &a[i]);
		sum += a[i];
	}
	double s;
	s = (sum * 1.0) / n;
	printf("%.2f", s);
	return 0;
}