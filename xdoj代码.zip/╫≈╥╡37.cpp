#include <stdio.h>

int main() {
	int a[100], b[100], c[100];
	int n, j = 0, k = 0;
	scanf("%d", &n);
	for (int i = 0; i < n; i++) {
		scanf("%d", &a[i]);
		if (a[i] % 2 == 0) {
			b[j] = a[i];
			j++;
		}
		if (a[i] % 2 != 0) {
			c[k] = a[i];
			k++;
		}
	}
	int n1, n2;
	n1 = j;
	n2 = k;
	for (int m = 0; m < n1 - 1; m++) {
		for (int i = m + 1; i < n1; i++) {
			if (b[m] < b[i]) {
				int t = b[m];
				b[m] = b[i];
				b[i] = t;
			}
		}
	}
	for (int m = 0; m < n2 - 1; m++) {
		for (int i = m + 1; i < n2; i++) {
			if (c[m] < c[i]) {
				int t = c[m];
				c[m] = c[i];
				c[i] = t;
			}
		}
	}
	for (int i = 0; i < n1; i++) {
		printf("%d ", b[i]);
	}
	for (int i = 0; i < n2; i++) {
		printf("%d ", c[i]);
	}
	return 0;



}