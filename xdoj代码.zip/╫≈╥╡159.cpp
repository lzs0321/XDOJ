#include <stdio.h>

int main() {
	int m, n, s, i;
	long int sum_m = 1, sum_n = 1, sum_s = 1;
	scanf("%d %d", &m, &n);
	for (i = 1; i <= m; i++) {
		sum_m *= i;
	}
	for (i = 1; i <= n; i++) {
		sum_n *= i;
	}
	for (i = 1; i <= (m - n); i++) {
		sum_s *= i;
	}
	float x = sum_m / sum_n / sum_s;
	printf("%.2f", x);
	return 0;
}
