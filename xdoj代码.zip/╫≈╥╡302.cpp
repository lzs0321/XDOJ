#include <stdio.h>
#include <math.h>

int main() {
	int n, i, j, count = 0;
	int sum = 0;
	scanf("%d", &n);
	for (i = 2; count <= n + 10; i++) {
		int a = (int)sqrt((double)i);
		for (j = 2; j <= a; j++) {
			if (i % j == 0) {
				break;
			}
		}
		if (j > a) {
			count++;
			if (count >= n && count <= n + 10) {
				sum += i;
			}
		}
	}
	printf("%d", sum);
	return 0;

}