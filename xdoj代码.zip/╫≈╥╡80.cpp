#include <stdio.h>
#include <string.h>

int main() {
	char c, a[100];
	int n, num = 0;
	scanf("%c %d\n", &c, &n);
	scanf("%s", a);
	if (n == 1) {
		for (int i = 0; i != '0'; i++) {
			if (c == a[i])
				num++;
		}
	} else if (n == 0) {

		if (c >= 'a' && c <= 'z') {
			for (int i = 0; i != '0'; i++) {
				if ( c == a[i]  || c - 32 == a[i] )
					num++;
			}
		}
		if (c >= 'A' && c <= 'Z') {
			for (int i = 0; i != '0'; i++) {
				if ( c == a[i]  || c + 32 == a[i])
					num++;
			}
		}
	}


	printf("%d", num);
	return 0;
}