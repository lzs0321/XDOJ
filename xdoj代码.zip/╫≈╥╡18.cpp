#include <stdio.h>

int main() {
	int a, m;
	char b, n;
	scanf("%d,%c", &a, &b);
	m = a + b;
	n = a + b;
	printf("%d,%c", n, m);
	return 0;


}