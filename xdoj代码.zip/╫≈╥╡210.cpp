#include <stdio.h>

void change(int *a, int n) {
	int i, t, max, min, locmax, locmin;
	max = *a;
	locmax = 0;
	min = *a;
	locmin = 0;
	for (i = 1; i < n; i++) {
		if (*(a + i) > max) {
			max = *(a + i);
			locmax = i;
		}
		if (*(a + i) < min) {
			min = *(a + i);
			locmin = i;
		}
	}
	t = *(a + locmax);
	*(a + locmax) = *(a + locmin);
	*(a + locmin) = t;
}

int main() {
	int a[20];
	int n, i;
	scanf("%d", &n);
	for (i = 0; i < n; i++) {
		scanf("%d", &a[i]);
	}
	change(a, n);
	for (i = 0; i < n; i++) {
		printf("%d ", a[i]);
	}
	return 0;
}