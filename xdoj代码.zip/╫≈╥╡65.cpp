#include <stdio.h>

int fib(int n) {
	int z, sum = 0;
	while (n != 0) {
		z = n % 10;
		n /= 10;
		sum += z;
	}
	if (sum > 9) {
		sum = fib(sum);
	}
	return sum;
}

int main() {
	int f, n;
	scanf("%d", &n);
	f = fib(n);
	printf("%d", f);
	return 0;
}