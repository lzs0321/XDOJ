#include <stdio.h>

int main() {
	int n, m, sum, cha, ji, shang, yu = 0;
	scanf("%d %d", &n, &m);
	sum = n + m;
	cha = n - m;
	ji = n * m;
	shang = n / m;
	yu = n % m;
	printf("%d %d %d %d %d", sum, cha, ji, shang, yu);
	return 0;
}