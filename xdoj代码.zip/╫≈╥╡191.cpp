#include <stdio.h>
#include <string.h>

int main() {
	char a[7], c;
	int i, j;
	gets(a);
	for (i = 0; i < strlen(a); i++) {
		c = a[i];
		if (c >= 'A' && c <= 'Z') {
			a[i] = 'A' + 'Z' - a[i];
		} else if (c >= 'a' && c <= 'z') {
			a[i] = 'a' + 'z' - a[i];
		}
	}
	puts(a);
	return 0;
}
