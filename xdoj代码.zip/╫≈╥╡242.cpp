#include <stdio.h>
#include <string.h>

typedef struct {
	int id;
	char name[11];
	double store;
} ST_INFO;

int compare(ST_INFO st1, ST_INFO st2) {
	if (st1.store > st2.store) {
		return 1;
	} else if (st1.store < st2.store) {
		return -1;
	} else {
		return st2.id - st1.id;
	}

}

int main() {
	int n, i, j, k;
	ST_INFO sts[100];
	scanf("%d", &n);
	for (i = 0; i < n; i++) {
		int s1, s2, s3;
		scanf("%d %s %d %d %d", &sts[i].id, sts[i].name, &s1, &s2, &s3);
		sts[i].store = (s1 + s2 + s3) / 3.0;
	}
	for (i = 0; i < n - 1; i++) {
		k = i;
		for (j = i + 1; j < n; j++) {
			if (compare(sts[j], sts[k]) > 0)
				k = j;
		}
		if (k != j) {
			ST_INFO t = sts[i];
			sts[i] = sts[k];
			sts[k] = t;
		}
	}
	for (i = 0; i < n; i++) {
		printf("%d %s %.1f\n", sts[i].id, sts[i].name, sts[i].store);

	}
	return 0;
}