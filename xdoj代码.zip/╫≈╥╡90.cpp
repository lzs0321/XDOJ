#include <stdio.h>

int main() {
	int a, b, c, d;
	scanf("%d", &d);
	c = d % 10;
	b = (d % 100) / 10;
	a = d / 100;
	printf("%d", a + b + c);
	return 0;

}