#include <stdio.h>
#include <math.h>

int main() {
	float x1 = 1.0, x2, x;
	int a;
	scanf("%d", &a);

	do {
		x2 = 1.0 / 2 * (x1 + a / x1);
		x = x1;
		x1 = x2;
	} while (fabs(x - x1) >= 1e-5);

	printf("%.5f", x1);
}
