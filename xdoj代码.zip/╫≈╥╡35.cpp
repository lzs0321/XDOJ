#include <stdio.h>
#include <math.h>

int main() {
	int n;
	scanf("%d", &n);
	int a, k, m, j, c, d;
	for (m = 2; m <= n; m++) {
		k = (int)sqrt((double)m);
		for (a = 2; a <= k; a++) {
			if (m % a == 0)
				break;
		}
		if (a > k) {
			j = n - m;
			d = (int)sqrt((double)j);
			for (c = 2; c <= d; c++) {
				if (j % c == 0)
					break;
			}
			if (c > d) {
				printf("%d %d", m, j);
				break;
			}
		}
	}
	return 0;
}