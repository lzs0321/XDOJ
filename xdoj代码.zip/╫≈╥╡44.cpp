#include <stdio.h>
#include <math.h>

int tow(int a) {
	int s;
	if (a == 1 || a == 2) {
		s = 1;
	} else {
		s = tow(a - 1) + tow(a - 2);
	}
	return s;
}

int main() {
	int n, s;
	scanf("%d", &n);
	s = tow(n);
	if (s == 1) {
		printf("%d", s);
	}
	int a, k;
	k = (int)sqrt((double)s);
	for (a = 2; a <= k; a++) {
		if (s % a == 0)
			break;
	}
	if (a > k)
		printf("Yes");
	else
		printf("%d", s);

	return 0;
}