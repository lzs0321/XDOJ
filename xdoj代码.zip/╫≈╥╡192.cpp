#include <stdio.h>

int main() {
	int a[5];
	scanf("%d,%d,%d,%d,%d", &a[0], &a[1], &a[2], &a[3], &a[4]);
	for (int i = 0; i < 3; i++ ) {
		int t = a[i];
		a[i] = a[4 - i];
		a[4 - i] = t;
	}
	for (int j = 0; j < 5; j++) {
		printf("%d ", a[j]);
	}
	return 0;
}