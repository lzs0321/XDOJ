#include <stdio.h>

int main() {
	int a;
	float b;
	scanf("%d", &a);
	b = (a - 32) * 5.0 / 9.0;
	printf("%.2f", b);
	return 0;
}
