#include <stdio.h>

int main() {
	int a[4];
	scanf("%d %d %d %d", &a[0], &a[1], &a[2], &a[3]);
	int maxn = a[0];
	for (int j = 0; j < 4; j++) {
		if (a[j] - maxn >= 0) {
			maxn = a[j];
		}
	}
	printf("%d", maxn);
	return 0;
}