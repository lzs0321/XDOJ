#include <stdio.h>
#include <math.h>

int main() {
	int n, a, c, t;
	scanf("%d", &n);
	t = n;
	a = 0;
	while (t > 9) {
		t /= 10;
		a++;
	}
	int sum = 0;
	int b = pow(10, a);
	do {
		c = n / b;
		n %= b;
		b /= 10;
		sum += c;
	} while (b > 0);
	printf("%d\n", sum);
	return 0;
}