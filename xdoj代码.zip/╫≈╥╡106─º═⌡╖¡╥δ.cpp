#include <stdio.h>
#include <string.h>
char B[] = "tsaedsae";
char A[] = "sae";
char s[1000];

void Print(char c) { //��ӡ����
	if (c == 'B')
		printf("%s", B);
	else if (c == 'A')
		printf("%s", A);
	else
		printf("%c", c);
}

int main() {
	char e; // �ظ��ַ�
	scanf("%s", s);
	int length = strlen(s);
	char k1;
	char k2;
	int key = 0;
	k2 = strchr(s, ')') - s; // )λ��
	k1 = strchr(s, '(') - s; // (λ��
	// �����������
	while (key != k1) {
		Print(s[key++]);
	}
	int i = k2 - 1;
	key = k2 + 1;
	e = s[k1 + 1];
	while (i != k1 + 1) {
		printf("%c", e);
		Print(s[i--]);
	}
	printf("%c", e);
	while (key < length)
		Print(s[key++]);
	return 0;
}