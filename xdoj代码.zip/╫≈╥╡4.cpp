#include <stdio.h>
#include <string.h>

int main() {
	char order[256], num[256], str[256];
	gets(order);
	int len = strlen(order);
	int i, j = 0, k, cnt = 0, count = 0;
	for (i = 0; i < len; i++) {
		if (order[i] == ' ')
			continue;
		else if (order[i] == '-') {
			num[j] = order[i + 1];
			j++;
			count++;
		} else
			continue;
	}
	if (count != 0) {
		for (i = 0; i < j; i++) {
			for (k = i + 1; k < j; k++) {
				if (num[i] == num[k]) {
					num[k] = 0;
					cnt++;
				}
			}
		}
		k = 0;
		for (i = 0; i < j; i++) {
			if (num[i]) {
				str[k] = num[i];
				k++;
			}
		}
		char temp;
		for (i = 0; i < k - 1; i++) {
			for (j = 0; j < k - 1 - i; j++) {
				if (str[j] > str[j + 1]) {
					temp = str[j];
					str[j] = str[j + 1];
					str[j + 1] = temp;
				}
			}
		}
		for (i = 0; i < k; i++) {
			printf("-%c ", str[i]);
		}
	} else
		printf("no");
	return 0;
}
