#include <stdio.h>

int main() {
	int n, i, j, sum = 0;
	int a[100][100];
	scanf("%d", &n);
	for (i = 1; i <= n; i++) {
		for (j = 1; j <= n; j++) {
			scanf("%d", &a[i][j]);
		}
	}
	for (i = 1, j = n; i <= n; i++, j--) {
		sum += a[i][i] ;
		if (i != j) {
			sum += a[i][j];
		}
	}
	printf("%d", sum);
	return 0;
}