#include <stdio.h>

struct document {
	int year;
	int month;
	int day;
	int size;
};

int main() {
	int n;
	int i, j;
	scanf("%d", &n);
	struct document doc[n], t;
	for (i = 0; i < n; i++) {
		scanf("%d/%d/%d %d", &doc[i].year, &doc[i].month, &doc[i].day, &doc[i].size);
	}
	for (i = 0; i < n - 1; i++) {
		for (j = 0; j < n - 1 - i; j++) {
			if (doc[j].year < doc[j + 1].year) {
				t = doc[j];
				doc[j] = doc[j + 1];
				doc[j + 1] = t;
			} else if (doc[j].year == doc[j + 1].year) {
				if (doc[j].month < doc[j + 1].month) {
					t = doc[j];
					doc[j] = doc[j + 1];
					doc[j + 1] = t;
				} else if (doc[j].month == doc[j + 1].month) {
					if (doc[j].day < doc[j + 1].day) {
						t = doc[j];
						doc[j] = doc[j + 1];
						doc[j + 1] = t;
					} else if (doc[j].day == doc[j + 1].day) {
						if (doc[j].size < doc[j + 1].size) {
							t = doc[j];
							doc[j] = doc[j + 1];
							doc[j + 1] = t;
						}
					}
				}
			}
		}
	}
	for (i = 0; i < n; i++) {
		printf("%d/%d/%d %d\n", doc[i].year, doc[i].month, doc[i].day, doc[i].size);
	}

	return 0;
}
