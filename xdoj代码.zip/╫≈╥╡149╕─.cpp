#include <stdio.h>

int main() {
	int N, i;
	int flag = 1;
	double d = 1;
	double sum = 0;
	scanf("%d", &N);
	for (i = 1; i <= N; i++) {
		sum = sum + flag * i / d * 1.0;
		flag = -flag;
		d += 2;
	}
	printf("%.3f", sum);
	return 0;
}
