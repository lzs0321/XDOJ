#include <stdio.h>
#include <math.h>

int main() {
	int n, a[100];
	scanf("%d", &n);
	for (int i = 0; i < n; i++) {
		scanf("%d", &a[i]);
	}
	for (int m = 0; m < n - 1; m++) {
		for (int i = m + 1; i < n; i++) {
			if (a[m] < a[i]) {
				int t = a[m];
				a[m] = a[i];
				a[i] = t;
			}
		}
	}
	int z = 0;
	for (int j = 0; j < n - 2; j++) {
		if ((a[j] - a[j + 1]) != (a[j + 1] - a[j + 2])) {
			z = 1;
			break;
		}
	}
	if (z == 1) {
		printf("no");
	} else if (z == 0) {
		int f = fabs(a[0] - a[1]);
		printf("%d", f);
	}
	return 0;
}