#include <stdio.h>
#include <iostream>
#include <queue>
using namespace std;
int num, num1, num2;
int cont = 0;
queue<int>data;
int i = 0;

int main() {
	int cout[100];
	int m, n;
	while (cin >> m >> n) {
		cont = 0;
		if (m == 0 && n == 0) { //�������0 0�ͽ���
			break;
		}
		data.push(m);
		cont++;
		while (!data.empty()) {
			num = data.front();
			num1 = 2 * num;
			num2 = 2 * num + 1;
			data.pop();
			if (num1 <= n) { //������ݺϷ��������
				data.push(num1);
				cont++;
			}
			if (num2 <= n) {
				data.push(num2);
				cont++;
			}

		}
		cout[i] = cont;
		i++;

	}
	for (int j = 0; j < i; j++)
		printf("%d\n", cout[j]);
	return 0;

}
