#include <stdio.h>

int main() {
	int x, a, b, c, d, e;
	scanf("%d", &x);
	a = x / 10000;
	b = (x % 10000) / 1000;
	c = (x % 1000) / 100;
	d = (x % 100) / 10;
	e = x % 10;
	printf("%d %d %d %d %d", a, b, c, d, e);
	return 0;

}