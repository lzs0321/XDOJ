#include <stdio.h>

int a(int n) {
	int A;
	if (n == 1)
		A = 2;
	else if (n == 2)
		A = 3;
	else
		A = a(n - 1) + a(n - 2);
	return A;
}

int b(int m) {
	int B;
	if (m == 1)
		B = 1;
	else if (m == 2)
		B = 2;
	else
		B = b(m - 1) + b(m - 2);
	return B;
}

int main() {
	int s;
	scanf("%d", &s);
	int i;
	double sum = 0.0;
	for (i = 1; i <= s; i++) {
		sum += (double)a(i) / (double)b(i);
	}
	printf("%.2f", sum);
	return 0;
}
