#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define MAXSIZE 10
#define ElemType char

typedef struct node {
	ElemType data;
	struct node *lchild, *rchild;
} BiNode, *BiTree;

int InSert (BiTree *T, ElemType key);
BiTree CreatBiTree (ElemType *p, int n);
int Judge (BiTree T1, BiTree T2);
void InOrderTraverse (BiTree T);
int main (void) {
	int n, i, j, len, len1, flag = 0, t;
	ElemType num[MAXSIZE];
	ElemType num1[MAXSIZE];
	int index[21];
	int check[100] = {0};
	int tip = 0;
	BiTree T1 = NULL, T2 = NULL;
	while (scanf ("%d", &n) && n) {
		t = n;
		scanf ("%s", num);
		len = strlen(num);
		//flag = 0;
		//printf ("%d",len);
		T1 = CreatBiTree (num, len);
		//InOrderTraverse (T1);
		while (n--) {
			scanf ("%s", num1);
			len1 = strlen (num1);
			T2 = CreatBiTree (num1, len1);
			//InOrderTraverse (T2);
			//index[flag] = Judge (T1, T2);
			//printf ("%d", Judge (T1, T2));
			//flag++;

			flag = Judge (T1, T2);
			if (flag == 1) {
				check[tip] = 1;
				tip++;
			} else {
				check[tip] = 0;
				tip++;
			}

		}

	}
	/*for (i = 0; i < t; i++) {
	    if (index[i] == 1) {
	        printf ("YES\n");
	    }
	    else {
	        printf ("NO\n");
	    }
	    //printf ("%d", index[i]);
	}*/

	/*for (j = 0; j < len + 1; j++) {
	    printf ("%d ",num[j]);
	}*/
	for (int p = 0; p < tip; p++) {
		if (check[p] == 1)
			printf("YES\n");
		else
			printf("NO\n");
	}
	return 0;
}

int InSert (BiTree *T, ElemType key) {
	if ((*T) == NULL) {
		(*T) = (BiTree)malloc(sizeof(BiNode));
		(*T)->data = key;
		(*T)->lchild = NULL;
		(*T)->rchild = NULL;
		return 1;
	} else if ((*T)->data == key)
		return 0;
	else if (key < (*T)->data)
		return InSert (&(*T)->lchild, key);
	else
		return InSert (&(*T)->rchild, key);
}

BiTree CreatBiTree (ElemType *p, int n) {
	BiTree T = NULL;
	int i = 0;
	while (i < n) {
		InSert (&T, *(p + i));
		i++;
	}
	return T;
}

int Judge (BiTree T1, BiTree T2) {
	if (T1 == NULL && T2 == NULL)
		return 1;
	else if (T1 == NULL && T2)
		return 0;
	else if (T1 && T2 == NULL)
		return 0;
	else if (T1->data != T2->data)
		return 0;
	else
		return (Judge (T1->lchild, T2->lchild) && Judge (T1->rchild, T2->rchild) || Judge (T1->lchild, T2->rchild)
		        && Judge (T1->rchild, T2->lchild));
}

void InOrderTraverse (BiTree T) {
	if (T) {
		InOrderTraverse (T->lchild);
		printf ("%c ", T->data);
		InOrderTraverse (T->rchild);
	}
}
