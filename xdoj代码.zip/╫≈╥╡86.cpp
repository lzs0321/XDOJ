#include <stdio.h>

int main() {
	int n, a, b, c, d;
	scanf("%d", &n);
	int num[101][101] = {0};
	for (int z = 0; z < n; z++) {
		scanf("%d %d %d %d", &a, &b, &c, &d);
		for (int i = a; i < c; i++) {
			for (int j = b; j < d; j++) {
				num[i][j] = 1;
			}
		}
	}
	int count = 0;
	for (int i = 0; i < 101; i++) {
		for (int j = 0; j < 101; j++) {
			if (num[i][j] == 1) {
				count++;
			}
		}
	}
	printf("%d", count);
	return 0;
}