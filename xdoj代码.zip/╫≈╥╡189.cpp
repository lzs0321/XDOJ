#include <stdio.h>
#include <math.h>

int main() {
	int n;
	scanf("%d", &n);
	double a, b, sum = 100.0;
	double s = 100.0, h, l = 100.0;
	for (int i = 2; i <= n; i++) {
		sum += s;
		s /= 2.0;
	}
	for (int i = 1; i <= n; i++) {
		l /= 2.0;
		h = l;
	}
	printf("S=%.3f h=%.3f", sum, h);

	return 0;
}
