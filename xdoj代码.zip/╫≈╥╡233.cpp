#include <stdio.h>
#include <string.h>

int main(int argc, char *argv[]) {
	int StartPos = 0;
	char StrBuffer[50];
	size_t StrLength = 0;
	gets(StrBuffer);
	StrLength = strlen(StrBuffer);
	scanf("%d", &StartPos);
	if (StartPos > StrLength) {
		printf("error");
		return 0;
	}
	printf("%s", &StrBuffer[StartPos - 1]);
	return 0;
}