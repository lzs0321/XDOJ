
#include <stdio.h>
#include <string.h>

void count(char a[], char b[]) {
	int i, j, num = 0;
	for (i = 0; i < strlen(a); ) {
		int flag = 0;
		for (j = 0; a[i + j] != ' ' && a[i + j] != '\0'; j++) {
			if (a[i + j] == b[j]) {
				flag += 1;
			}
		}
		i = i + j + 1;
		if (flag == strlen(b) && j == strlen(b))
			num++;
	}
	printf("%s %d", b, num);
}

int main() {
	char string[100], word[8];
	gets(string);
	gets(word);
	count(string, word);

	return 0;
}