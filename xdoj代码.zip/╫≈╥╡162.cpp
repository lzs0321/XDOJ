#include <stdio.h>

int main() {
	int a[2][3], b[3][2], c[2][2] = {0};
	int i, j, k;
	scanf("%d %d %d %d %d %d", &a[0][0], &a[0][1], &a[0][2], &a[1][0], &a[1][1], &a[1][2]);
	scanf("%d %d %d %d %d %d", &b[0][0], &b[0][1], &b[1][0], &b[1][1], &b[2][0], &b[2][1]);
	for (int i = 0; i < 2; i++) {
		for (int j = 0; j < 2; j++) {
			for (k = 0; k < 3; k++) {
				c[i][j] += a[i][k] * b[k][j];
			}
		}
	}
	for (int i = 0; i < 2; i++) {
		for (int j = 0; j < 3; j++) {
			printf("%5d ", a[i][j]);
		}
		printf("\n");
	}
	for (int i = 0; i < 3; i++) {
		for (int j = 0; j < 2; j++) {
			printf("%5d ", b[i][j]);
		}
		printf("\n");
	}
	for (int i = 0; i < 2; i++) {
		for (int j = 0; j < 2; j++) {
			printf("%5d ", c[i][j]);
		}
		printf("\n");
	}

	return 0;
}