#include <stdio.h>

int main() {
	int s, t;
	scanf("%d", &s);
	t = s - 3500;
	if (t <= 0)
		printf("%d", s);
	else if (t <= 1500)
		printf("%d", s - (s - 3500) * 3 / 100);
	else if (t <= 4500)
		printf("%d", s - 1500 * 3 / 100 - (s - 5000) / 10);
	else if (t <= 9000)
		printf("%d", s - 1500 * 3 / 100 - 3000 / 10 - (s - 8000) * 2 / 10);
	else if (t <= 35000)
		printf("%d", s - 1500 * 3 / 100 - 3000 / 10 - 4500 * 2 / 10 - (s - 12500) * 25 / 100);
	else
		printf("%d", s - 1500 * 3 / 100 - 3000 / 10 - 4500 * 2 / 10 - 26000 * 25 / 100 - (s - 38500) * 3 / 10);
	return 0;
}