#include <stdio.h>

int main() {
	int n;
	scanf("%d\n", &n);
	int a[10000];
	for (int i = 0; i < n ; i++) {
		scanf("%d", &a[i]);
	}
	int b[10000] = {0};
	for (int i = 0; i < n; i++) {
		int m = a[i];
		while (m != 0) {
			b[i] += m % 10;
			m /= 10;
		}
	}
	for (int j = 0; j < n - 1; j++) {
		for (int k = j + 1; k < n; k++) {
			if (b[j] < b[k]) {
				int c = b[j], d = a[j];
				b[j] = b[k], b[k] = c;
				a[j] = a[k], a[k] = d;
			}
			if (b[j] == b[k]) {
				if (a[j] > a[k]) {
					int p = a[j];
					a[j] = a[k], a[k] = p;
				}
			}
		}
	}
	for (int s = 0; s < n; s++) {
		printf("%d %d\n", a[s], b[s]);
	}
	return 0;
}