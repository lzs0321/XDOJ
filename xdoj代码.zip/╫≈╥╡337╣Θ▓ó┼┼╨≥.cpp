#include <stdio.h>

int main() {
	int i, j, k, m, n;
	scanf("%d%d", &n, &m);
	int a[n];
	int b[m];
	int c[m + n];
	for (i = 0; i < n; i++) {
		scanf("%d", &a[i]);
	}

	for (i = 0; i < m; i++) {
		scanf("%d", &b[i]);
	}
	i = 0;
	j = 0;
	k = 0;
	while (j < n && k < m) {
		if (a[j] < b[k]) {
			c[i] = a[j];
			j++;
		} else {
			c[i] = b[k];
			k++;
		}
		i++;
	}

	while (j < n) {
		c[i] = a[j];
		j++;
		i++;
	}
	while (k < m) {
		c[i] = b[k];
		k++;
		i++;
	}
	for (i = 0; i < n + m; i++) {
		printf("%d ", c[i]);
	}
}
