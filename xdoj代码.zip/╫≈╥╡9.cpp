#include <stdio.h>
#include <math.h>

int main() {
	int a, b;
	float c, d;
	scanf("%d %d", &a, & b);
	c = 7.86 * 3.1415926 * (4.0 / 3.0) * (a * 0.1 / 2) * (a * 0.1 / 2) * (a * 0.1 / 2);
	d = 19.3 * 3.1415926 * (4.0 / 3.0) * (b * 0.1 / 2) * (b * 0.1 / 2) * (b * 0.1 / 2);
	printf("%.3f %.3f", c, d);

	return 0;
}