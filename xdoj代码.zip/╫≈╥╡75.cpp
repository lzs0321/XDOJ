#include <stdio.h>

int main() {
	int m, n, z = 0;
	scanf("%d %d", &m, &n);
	int a[256][256], b[100000] = {0}, c[100000000] = {0};
	for (int i = 0; i < n; i++) {
		for (int j = 0; j < m; j++) {
			scanf("%d", &a[i][j]);
			c[z] = a[i][j];
			z++;
		}
	}
	for (int i = 0; i < z; i++) {
		for (int j = 0; j < z; j++) {
			if (c[i] - c[j] >= 0) {
				int r = c[i];
				c[i] = c[j];
				c[j] = r;
			}
		}
	}
	int x = 0;
	for (int i = 0; i < z; i++) {
		for (int j = 0; j < z; j++) {
			if (c[i] == c[j]) {
				b[i]++;
			}
		}
	}
	for (int i = 0; i < z - 1; i++) {
		if (c[i] == c[i + 1]) {
			continue;
		}
		printf("%d %d\n", c[i], b[i]);
	}
	printf("%d %d", c[z - 1], b[z - 1]);
	return 0;

}