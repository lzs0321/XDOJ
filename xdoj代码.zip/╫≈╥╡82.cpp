#include <stdio.h>
#include <string.h>

int main() {
	int n = 0, i, m, a = 0, b = 0, c = 0, d = 0, e = 0;
	char str[50];
	gets(str);
	m = strlen(str);
	if (m > 8)
		n = n + 1;
	for (i = 0; i < m; i++) {
		if (str[i] != ' ')
			e++;
		if (str[i] >= '0' && str[i] <= '9') {
			a++;
			continue;
		}
		if (str[i] >= 'A' && str[i] <= 'Z') {
			b++;
			continue;
		}
		if (str[i] >= 'a' && str[i] <= 'z') {
			c++;
			continue;
		} else
			d++;
	}
	if (a != 0)
		n = n + 1;
	if (b != 0)
		n = n + 1;
	if (c != 0)
		n = n + 1;
	if (d != 0)
		n = n + 1;
	if (e != 0) {
		n = n + 1;
		printf("%d", n - 1);
	}
	if (e == 0)
		printf("0");
	return 0;
}
