#include <stdio.h>
#include <string.h>

int main() {
	char a[101], b[101];
	int cont, cont2;
	gets(a);
	gets(b);
	int sum[101][101] = {0};
	int maxn = 0;
	cont = strlen(a);
	cont2 = strlen(b);
	for (int i = 0; i < cont2; i++) {
		for (int l = 0; l < cont; l++) {
			if (b[i] == a[l] || b[i] == a[l] + 32 || b[i] == a[l] - 32) {
				if (i == 0 || l == 0) {
					sum[i][l] = 1;
				} else {
					sum[i][l] = sum[i - 1][l - 1] + 1;
				}
			}
			if (sum[i][l] > maxn) {
				maxn = sum[i][l];
			}

		}
	}
	double p;
	p = 2.0 * maxn / (cont + cont2);
	printf("%.3f", p);
	return 0;
}