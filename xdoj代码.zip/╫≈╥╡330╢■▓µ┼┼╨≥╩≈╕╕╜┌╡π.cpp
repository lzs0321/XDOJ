#include <iostream>
#include <cstdio>
using namespace std;

struct node {
	node *lchild;
	node *rchild;
	int val;
} *root;

void dfs(node *p, int tmp) {
	if (tmp < p->val) {
		if (p->lchild)
			dfs(p->lchild, tmp);
		else {
			node *t = new node;
			t->lchild = NULL;
			t->rchild = NULL;
			t->val = tmp;
			p->lchild = t;
			printf("%d\n", p->val);
			//printf("lchild %d\n",p->lchild->val);
			return;
		}
	}
	if (tmp > p->val) {
		if (p->rchild)
			dfs(p->rchild, tmp);
		else {
			node *t = new node;
			t->lchild = NULL;
			t->rchild = NULL;
			t->val = tmp;
			p->rchild = t;
			printf("%d\n", p->val);
			//printf("rchild %d\n",p->rchild->val);
			return;
		}
	}
}

int main() {
	int n, tmp, i;
	while (scanf("%d", &n)) {
		scanf("%d", &tmp);
		node *t = new node;
		t->lchild = NULL;
		t->rchild = NULL;
		t->val = tmp;
		root = t;

		printf("-1\n");
		for (i = 1; i < n; i++) {
			scanf("%d", &tmp);
			dfs(root, tmp);
		}
	}
	return 0;
}

