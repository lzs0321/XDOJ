#include <stdio.h>
#include <math.h>

int main() {
	double n;
	scanf("%lf", &n);
	if (n >= 90.0) {
		printf("%.2f A", n);
	} else if (n >= 80.0 && n < 90.0) {
		printf("%.2f B", n);
	} else if (n >= 70.0 && n < 80.0) {
		printf("%.2f C", n);
	} else if (n >= 60.0 && n < 70.0) {
		printf("%.2f D", n);
	} else {
		printf("%.2f E", n);
	}

	return 0;
}