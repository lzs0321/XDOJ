#include <stdio.h>

int main() {
	int a, b, c, d, t, m;
	scanf("%d %d", &a, &b);
	c = a;
	d = b;
	while (b != 0) {
		t = a % b;
		a = b;
		b = t;
	}
	for (int i = 1; i > 0; i++) {
		m = c * i;
		if (m % d == 0) {
			break;
		}
	}
	printf("%d %d", a, m);
	return 0;
}