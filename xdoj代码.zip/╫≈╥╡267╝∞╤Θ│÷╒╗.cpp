#include <stdio.h>
#include <stdlib.h>

typedef struct stack {
	int data[1000];
	int top;
} st; //����ṹ�塪��ջ
st *tops;

st *setnulls(st *s) {
	s->top = -1;
	return s;
}//�ÿ�ջ

st *pushs(st *tops, int e) {
	tops->top++;
	tops->data[tops->top] = e;
	return tops;
}//��ջ��������ջ��Ԫ��

int pops(st *top) {
	int ret;
	if (tops->top == -1)
		return  0;
	else {
		ret = tops->data[tops->top];
		tops->top--;
		return ret;
	}
}//ɾ��������ջ��Ԫ��

int judge(st *tops, int n, int y[], int m, int s[]) {
	int i = 0, j = 0;
	setnulls(tops);//�ÿ�ջ
	tops = pushs(tops, s[i]);//����һ��Ԫ����ջ��topsΪջ��Ԫ��
	while (tops->top < m && j < n) {
		if (tops->data[tops->top] == y[j] && tops->top != -1) {
			pops(tops);
			j++;
		} else {
			i++;
			tops = pushs(tops, s[i]);
		}
	}
	if (tops->top == -1)
		return 1;
	else
		return 0;
}

int main() {
	tops = (st *)malloc(sizeof(st));
	int m, n, k, i, j, y[1000], s[1000], h[10000];
	scanf("%d %d %d", &m, &n, &k);
	for (i = 0; i < n; i++)
		scanf("%d", &s[i]);
	for (i = 0; i < k; i++) {
		for (j = 0; j < n; j++) {
			scanf("%d", &y[j]);
		}
		h[i] = judge(tops, n, y, m, s);
	}
	for (i = 0; i < k; i++) {
		if (h[i] == 1)
			printf("YES");
		else
			printf("NO");
		if (i != k - 1)
			printf("\n");
	}
	return 0;
}
