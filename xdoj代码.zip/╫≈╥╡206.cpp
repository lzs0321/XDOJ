#include <stdio.h>
#include <string.h>

int main() {
	void dele(char str[], char s[], char c);
	char str[100], s[100], c;
	gets(str);
	scanf("%c", &c);
	dele(str, s, c);
}

void dele(char str[], char s[], char c) {
	int len1 = strlen(str);
	int len2 = 0;
	for (int i = 0; i < len1; i++) {
		if (str[i] != c) {
			s[len2++] = str[i];

		}
	}

	puts(s);
}