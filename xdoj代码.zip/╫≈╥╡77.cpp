#include <stdio.h>
#include <string.h>

int main() {
	char s[100], c;
	int k = 0, b, a[5], i = 0, len;
	a[0] = a[1] = 0;
	gets(s);
	len = strlen(s);
	while (i < len) {
		if (s[i] >= '0' && s[i] <= '9') {
			a[k] = a[k] * 10 + s[i] - '0';
			i++;
			while (s[i] >= '0' && s[i] <= '9' && i < len) {
				a[k] = a[k] * 10 + s[i] - '0';
				i++;
			}
			k++;
		} else if (s[i] != ' ') {
			c = s[i];
			i++;
		} else
			i++;
	}
	if (c == '+')
		b = a[0] + a[1];
	if (c == '-')
		b = a[0] - a[1];
	if (c == '*')
		b = a[0] * a[1];
	if (c == '/')
		b = a[0] / a[1];
	if (c == '%')
		b = a[0] % a[1];
	printf("%d", b);
}

