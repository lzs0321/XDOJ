#include <stdio.h>

int main() {
	int n;
	scanf("%d", &n);
	int num[101];
	for (int i = 0; i < n; i++) {
		scanf("%d", &num[i]);
	}
	for (int k = 0; k < n; k++) {
		for (int l = k + 1; l < n; l++) {
			if (num[k] > num[l]) {
				int idex = num[k];
				num[k] = num[l];
				num[l] = idex;
			}
		}

	}
	for (int j = 0; j < n; j++) {
		printf("%d ", num[j]);
	}
	return 0;

}