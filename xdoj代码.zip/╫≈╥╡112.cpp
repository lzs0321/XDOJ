#include <stdio.h>
#include <math.h>

int main() {
	double m, x;
	scanf("%lf", &x);
	if (x >= 0.0) {
		m = sqrt(x);
	} else {
		m = (x + 1) * (x + 1) + (2 * x) + (1 / x);
	}
	printf("%.2f", m);
	return 0;
}