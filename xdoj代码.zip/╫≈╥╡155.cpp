#include <stdio.h>

int main() {
	int n, z;
	scanf("%d", &n);
	int sum = 0;
	for (int j = 1; j <= n; j++) {
		z = 1;
		for (int k = 1; k <= j; k++) {
			z *= k;

		}
		sum += z;
	}
	printf("%d %d %d", n, z, sum);
	return 0;
}