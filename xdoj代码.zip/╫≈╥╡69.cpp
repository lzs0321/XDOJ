#include <stdio.h>

int main() {
	int N[100][100] = {0};
	int i = 0, j = 0;
	int m, n;
	scanf("%d %d", &m, &n);
	for (i = 0; i < m; i++) {
		for (j = 0; j < n; j++) {
			scanf("%d", &N[i][j]);
		}
	}
	for (i = 0; i < m; i++) {
		int max = 0, count = 0, l = 0, sign = 0;
		for (j = 0; j < n; j++) {
			if (N[i][j] == 1) {
				count++;
				sign = 1;
				if (j < n - 1) {
					if (N[i][j + 1] == 0) {
						max = count;
						l = j;
						count = 0;
					}
					if (N[i][j + 1])
						continue;
				} else if (j + 1 == n) {
					if (count > max) {
						max = count;
						l = j;
						count = 0;
					}
				}
			}
		}
		if (sign)
			printf("%d %d\n", l - max + 1, l);
		else {
			printf("-1 -1\n");
		}
	}
	return 0;
}
