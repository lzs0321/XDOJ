#include <stdio.h>

int main() {
	int m, n;
	int i, j;
	int count_1 = 0, count_2 = 0, sum_1 = 0, sum_2 = 0;

	scanf("%d %d", &m, &n);

	for (i = 1; i <=  m / 2; i++) {
		if (m % i == 0) {
			sum_1 += i;
			count_1++;
		}
	}

	for (j = 1; j <= n / 2; j++) {
		if (n % j == 0) {
			sum_2 += j;
			count_2++;
		}
	}

	if (sum_1 == n && sum_2 == m) {
		printf("yes %d %d", count_1, count_2);
	} else {
		printf("no %d %d", count_1, count_2);
	}

	return 0;
}