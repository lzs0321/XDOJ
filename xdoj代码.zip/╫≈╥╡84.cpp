#include <stdio.h>
#include <string.h>

int main() {
	char a[201], b[201];
	int len, i, j;
	gets(a);
	while (1) {
		gets(b);
		if (strcmp(b, "pwd") == 0) {
			break;
		}
		if (strlen(b) == 5 && b[3] == '.' && b[4] == '.') {
			len = strlen(a);
			if (len == 1)
				continue;
			for (i = len - 1; a[i] != '/'; i--) {
				a[i] = 0;
			}
			a[i] = 0;
			if (strlen(a) == 0)
				a[0] = '/';
			continue;
		}
		if (strlen(b) >= 4 && b[3] == '/') {
			j = 0;
			for (i = 3; b[i] != '\0'; i++) {
				a[j++] = b[i];
			}
			a[j] = 0;
			continue;
		}
		if (strlen(b) >= 4 && b[3] != '/') {
			j = strlen(a);
			if (j != 1) {
				a[j++] = '/';
			}
			for (i = 3; b[i] != '\0'; i++) {
				a[j++] = b[i];
			}
			a[j] = 0;
			continue;
		}
	}
	printf("%s", a);
	return 0;
}