#include <stdio.h>
#include <string.h>

void sort(char c[]) {
	int i, j;
	int len = strlen(c);
	char temp;
	for (i = 0; i < len; i++)
		for (j = 0; j < len - 1 - i; j++)
			if (c[j] > c[j + 1]) {
				temp = c[j];
				c[j] = c[j + 1];
				c[j + 1] = temp;
			}
}

int main() {

	char a[100] = { 0 }, b[100] = { 0 }, c[100] = { 0 };
	int len, j = 0, k = 0, i;
	char s;
	scanf("%s", a);
	len = strlen(a);
	s = a[0];
	for (i = 1; i < len; i++) {
		if (a[i] > s)
			b[j++] = a[i];
		if (a[i] <= s)
			c[k++] = a[i];
	}
	sort(c);
	for (i = 0; i < j; i++)
		printf("%c", b[i]);
	printf("%c", s);
	for (i = 0; i < k; i++)
		printf("%c", c[i]);

	return 0;
}