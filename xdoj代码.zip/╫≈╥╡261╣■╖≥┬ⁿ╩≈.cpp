#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#define MAXSIZE 100

typedef struct node {
	int weight;
	struct node *lchild, *rchild;
	struct node *parent;
} Bitree;

typedef struct linkList {
	Bitree *data;
	struct linkList *next;
} list;

void Insert(Bitree *tree, list *head) { //�Խڵ�Ȩֵ������������
	list *p, *s;
	int temp = 0;
	s = NULL;
	s = (list *)malloc(sizeof(list));
	s->data = tree;
	p = head;
	while (p->next != NULL) {
		if ((s->data->weight) < (p->next->data->weight)) {
			s->next = p->next;
			p->next = s;
			temp = 1;
			break;
		}
		p = p->next;
	}
	if (temp == 0) { //ĩβ�������
		p->next = s;
		s->next = NULL;
	}
}
// Insert

void Delt(list *head) {
	list *p;
	p = head;
	p->next = p->next->next->next;
}
// Delt

list *init_tree(int n) { //����ʼ���Ľڵ㴢����������
	int temp = 0;
	int ori_num;
	Bitree *tree;
	list *r, *s, *head;
	head = (list *)malloc(sizeof(list));
	r = head;
	while (temp < n) {
		scanf("%d", &ori_num);
		tree = NULL;
		tree = (Bitree *)malloc(sizeof(Bitree));
		tree->weight = ori_num;
		tree->lchild = NULL;
		tree->rchild = NULL;
		tree->parent = NULL;
		if (temp == 0) {
			s = (list *)malloc(sizeof(list));
			s->data = tree;
			r->next = s;
			r = s;
			r->next = NULL;
			temp++;
		} else {
			Insert(tree, head);
			temp++;
		}
	}
	return head;
}//��ʱ��������Ȩֵ�����ĵ�����
// init_tree

Bitree *Huffman(list *head) {
	Bitree *tree;
	list *p, *s;
	p = head;
	s = NULL;
	tree = NULL;
	if (p->next->next == NULL) {
		return p->next->data;
	} else {
		while (p->next->next != NULL) {
			tree = (Bitree *)malloc(sizeof(Bitree));
			tree->weight = p->next->data->weight + p->next->next->data->weight;
			tree->parent = NULL;
			tree->lchild = p->next->data;
			p->next->data->parent = tree;
			tree->rchild = p->next->next->data;
			p->next->next->data->parent = tree;
			Delt(head);
			Insert(tree, head);
		}
		return p->next->data;
	}
}
// Huffman

int Deep(Bitree *tree) { //��Ҷ�ӽڵ�����
	if (tree != NULL) {
		int deep = 0;
		Bitree *t;
		t = tree;
		while (t->parent != NULL) {
			t = t->parent;
			deep++;
		}
		return deep;
	}
}
// Deep

int sum = 0;
void output(Bitree *tree) { //������������ļ�Ȩ·������
	if (tree != NULL) {
		if ((tree->lchild == NULL) && (tree->rchild == NULL)) {
			sum += tree->weight * Deep(tree);
		}
		output(tree->lchild);
		output(tree->rchild);
	}
}
// output

int main() {
	int number;
	scanf("%d", &number);
	list *s;
	s = init_tree(number);
	Bitree *t;
	t = Huffman(s);
	output(t);
	printf("%d", sum);
}

