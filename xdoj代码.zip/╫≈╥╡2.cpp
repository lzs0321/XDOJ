#include <stdio.h>

int main() {
	int n;
	scanf("%d\n", &n);
	int a[1000];
	for (int i = 0; i < n ; i++) {
		scanf("%d", &a[i]);
	}
	int sum = 1;
	for (int j = 0; j < n - 1; j++) {
		if (a[j] == a[j + 1]) {
			continue;
		} else {
			sum++;
		}
	}
	printf("%d", sum);
	return 0;
}