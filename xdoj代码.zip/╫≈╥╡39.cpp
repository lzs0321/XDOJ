#include <stdio.h>

int main() {
	int a[100][100], b[100], c[100], d = 0, i, j, m, n;
	scanf("%d %d", &m, &n);
	for (i = 0; i < m; i++)
		for (j = 0; j < n; j++)
			scanf("%d", &a[i][j]);
	for (i = 0; i < m; i++)
		for (b[i] = a[i][0], j = 1; j < n; j++)
			if (b[i] > a[i][j])
				b[i] = a[i][j];
	for (j = 0; j < n; j++)
		for (c[j] = a[0][j], i = 1; i < m; i++)
			if (c[j] < a[i][j])
				c[j] = a[i][j];
	for (i = 0; i < m; i++)
		for (j = 0; j < n; j++) {
			if (b[i] == c[j]) {
				printf("%d %d %d\n", i, j, b[i]);
				d++;
			}
		}
	if (d == 0)
		printf("no\n");
	return 0;
}
