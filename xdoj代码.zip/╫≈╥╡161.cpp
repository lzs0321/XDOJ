#include <stdio.h>

int main() {
	int n;
	int sum = 0, sum2 = 0, sum3 = 0, sum4 = 0, sum5 = 0;
	scanf("%d", &n);
	for (int i = 1; i <= n; i++) {
		if (i % 2 == 0) {
			sum++;
		} else {
			sum2++;
		}
	}
	for (int i = 1; i <= n; i++) {
		if (i % 3 == 0) {
			sum3++;
		}
	}
	for (int i = 1; i <= n; i++) {
		if (i % 5 == 0) {
			sum4++;
		}
	}
	for (int i = 1; i <= n; i++) {
		if (i % 7 == 0) {
			sum5++;
		}
	}


	printf("%d %d %d %d %d", sum2, sum, sum3, sum4, sum5);
	return 0;
}