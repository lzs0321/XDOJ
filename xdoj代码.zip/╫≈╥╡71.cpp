#include <stdio.h>

int main() {
	int n, m, t, k, z = 0, l = 0;
	scanf("%d %d %d %d", &n, &m, &t, &k);
	int a[20][20], b[400] = {0};
	for (int i = 0; i < n; i++) {
		for (int j = 0; j < m; j++) {
			scanf("%d", &a[i][j]);
		}
	}
	for (int q = 0; q < n ; q++) {
		for (int w = 0; w < m - 1; w++) {
			if (a[q][w] == k) {
				if (a[q][w + 1] != k) {
					z++;
					b[l] = a[q][w + 1];
					l++;
				}
				continue;
			} else {
				if (a[q][w + 1] == k) {
					z++;
					b[l] = a[q][w];
					l++;
				}

			}
		}
	}
	for (int w = 0; w < m ; w++) {
		for (int q = 0; q < n - 1; q++) {
			if (a[q][w] == k) {
				if (a[q + 1][w] != k) {
					z++;
					b[l] = a[q + 1][w];
					l++;
				}
			} else {
				if (a[q + 1][w] == k) {
					z++;
					b[l] = a[q][w];
					l++;
				}

			}
		}
	}
	int sum = 0;
	for (int i = 0; i < l; i++) {
		for (int j = 0; j < l; j++) {
			if (b[i] - b[j] >= 0) {
				int r = b[i];
				b[i] = b[j];
				b[j] = r;
			}
		}
	}
	for (int i = 0; i < l - 1; i++) {
		if (b[i] == b[i + 1]) {
			z--;
		}
	}
	printf("%d", z);
	return 0;
}