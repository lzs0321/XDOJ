#include <stdio.h>
#include <stdlib.h>

typedef struct node {
	int data, val;       //dataΪ�ڵ�ֵ��valΪ���ֵ
	struct node *lchild, *rchild;
} Node;

//�������������
//�ڹ���ʱӦ����&T
void CreateTree1(Node *&T, int *pre, int *in, int n) {
	if (n == 0)
		return;
	int i;
	for (i = 0; i < n; i++) {
		if (in[i] == *pre)
			break;
	}
	T = (Node *)malloc(sizeof(Node));
	T->data = *pre;
	T->lchild = T->rchild = NULL;

	CreateTree1(T->lchild, pre + 1, in, i);
	CreateTree1(T->rchild, pre + 1 + i, in + 1 + i, n - 1 - i);
}

//������ͣ�������ԭ����val��
void CreateTree2(Node *&T) {
	if (T->lchild == NULL && T->rchild == NULL) {
		T->val = 0;
		return;
	} else if (T->lchild == NULL) {
		CreateTree2(T->rchild);
		T->val = T->rchild->data + T->rchild->val;
	} else if (T->rchild == NULL) {
		CreateTree2(T->lchild);
		T->val = T->lchild->data + T->lchild->val;
	} else {
		CreateTree2(T->lchild);
		CreateTree2(T->rchild);
		T->val = T->lchild->data + T->lchild->val + T->rchild->data + T->rchild->val;
	}
}


void InOrder(Node *T) {
	if (T == NULL)
		return;
	InOrder(T->lchild);
	printf("%d ", T->val);
	InOrder(T->rchild);
}

int main() {
	int n;
	scanf("%d", &n);
	int pre[n], in[n];
	int i;
	for (i = 0; i < n; i++) {
		scanf("%d", &pre[i]);
	}
	for (i = 0; i < n; i++) {
		scanf("%d", &in[i]);
	}

	Node *T;
	CreateTree1(T, pre, in, n);
	CreateTree2(T);
	InOrder(T);
	return 0;
}