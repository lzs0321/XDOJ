#include <stdio.h>

int main() {
	int a, b, c;
	scanf("%d %d", &a, &b);
	if (a % 4 == 0 && a % 100 != 0 || a % 400 == 0) {
		c = 29;
	} else {
		c = 28;
	}
	if (b == 1 || b == 3 || b == 5 || b == 7 || b == 8 || b == 10 || b == 12) {
		printf("31");
	} else if (b == 2) {
		printf("%d", c);
	} else {
		printf("30");
	}
	return 0;
}