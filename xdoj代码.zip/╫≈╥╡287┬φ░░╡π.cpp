#include <stdio.h>
#include <stdlib.h>
#define MAXSIZE 100

int main() {
	int mat[MAXSIZE][MAXSIZE];	//����
	int row[MAXSIZE];	//��
	int col[MAXSIZE];	//��
	int m, n;
	int i, j, max, min, flag = 0;
	scanf("%d %d", &m, &n);
	//�������
	for (i = 1; i <= m; i++) {
		for (j = 1; j <= n; j++) {
			scanf("%d", &mat[i][j]);
		}
	}

	//�ҵ�ÿ����С��
	for (i = 1; i <= m; i++) {
		min = mat[i][1];
		for (j = 1; j <= n; j++) {
			if (mat[i][j] <= min) {
				min = mat[i][j];
				row[i] = j;
			}
		}
	}

	//�ҵ�ÿ������
	for (j = 1; j <= n; j++) {
		max = mat[1][j];
		for (i = 1; i <= m; i++) {
			if (mat[i][j] >= max) {
				max = mat[i][j];
				col[j] = i;
			}
		}
	}

	//Ѱ��������
	for (i = 1; i <= m; i++) {
		j = row[i];
		if (col[j] == i) {
			printf("%d %d %d\n", i, j, mat[i][j]);
			flag = 1;
		}
	}

	if (flag == 0)
		printf("NO");

	return 0;
}