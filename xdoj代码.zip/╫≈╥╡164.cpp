#include <stdio.h>
#include <string.h>

int main() {
	int i, j;
	char str[80];
	char tmp;
	scanf("%s", str);
	for (i = 0; i < strlen(str); i++) {
		if (str[i] >= 97 && str[i] <= 122)
			str[i] = str[i] - 32;
	}
	for (i = 0; i < strlen(str) - 1; i++) {
		for (j = i + 1; j < strlen(str); j++) {
			if (str[i] >= 65 && str[i] <= 90 && str[j] >= 65 && str[j] <= 90 && str[i] > str[j]) {
				tmp = str[i];
				str[i] = str[j];
				str[j] = tmp;
			}
		}
	}

	printf("%s", str);
	return 0;
}