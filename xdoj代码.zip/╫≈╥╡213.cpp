#include <stdio.h>

void place(int *p, int *p1, int a, int b) {
	int i, w = 0, g, t;
	for (i = 1; i <= a; i = i + 2) {
		t = b;
		w = 0;
		p = p1 + i * b - 1;
		while (w < b / 2) {

			g = *p;
			*p = *(p - t + 1);
			*(p - t + 1) = g;
			t -= 2;
			w++;
			p--;
		}


	}

}

int main() {
	int num[50], m, n, i, j, t;
	double w;
	scanf("%d%d", &m, &n);
	for (i = 0; i < m * n; i++)
		scanf("%d", &num[i]);
	for (i = 0; i < m * n - 1; i++)
		for (j = 0; j < m * n - 1 - i; j++) {
			if (num[j] > num[j + 1]) {
				t = num[j];
				num[j] = num[j + 1];
				num[j + 1] = t;

			}
		}
	place(num, num, m, n);
	for (i = 0; i < m * n - n; i++) {
		printf("%3d", num[i]);
		w = (i + 1) % n;
		if (w == 0)
			printf("\n");
	}
	for (i = m * n - n; i < m * n; i++)
		printf("%3d", num[i]);
	return 0;

}
