#include <stdio.h>

int main() {
	int m, p;
	double s;
	scanf("%lf %d", &s, &m);
	p = (m / 5) * 2;
	double c;
	if (s <= 3.0) {
		c = 10.0 + p;
	} else if (s > 3.0 && s <= 10.0) {
		c = 10.0 + (s - 3.0) * 2 + p;
	} else {
		c = 24.0 + (s - 10.0) * 3 + p;
	}
	printf("%d", int(c + 0.5) );
	return 0;
}