#include <stdio.h>
#include <string.h>

int main() {
	int n, len, i;
	char str[50];
	gets(str);
	scanf("%d", &n);
	len = strlen(str);
	for (i = n + 1; i < len; i++) {
		printf("%c", str[i]);
	}
	return 0;
}