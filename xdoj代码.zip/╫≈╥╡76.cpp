#include <stdio.h>

int main() {
	int n;
	scanf("%d\n", &n);
	int a[1000];
	for (int i = 0; i < n ; i++) {
		scanf("%d", &a[i]);
	}
	int b[25] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
	for (int i = 0; i < n ; i++) {
		for (int j = 0; j < n; j++) {
			if (a[i] == a[j]) {
				b[i]++;
			}
		}
	}
	for (int i = 0; i < n - 1; i++) {
		for (int j = i + 1; j < n; j++) {
			if (a[i] >= a[j]) {
				int m = a[i], n = b[i];
				a[i] = a[j], a[j] = m;
				b[i] = b[j], b[j] = n;
			}
		}
	}
	for (int i = 0; i < n - 1; i++) {
		if (a[i] == a[i + 1]) {
			continue;
		}
		printf("%d:%d\n", a[i], b[i]);
	}
	printf("%d:%d", a[n - 1], b[n - 1]);
	return 0;
}