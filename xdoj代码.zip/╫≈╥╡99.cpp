#include <stdio.h>
#include <math.h>

int main() {
	double n, p, s;
	char m;
	scanf("%lf", &n);
	if (n <= 110.0) {
		p = n * 0.5;
		m = 'A';
		s = 0.0;
	} else if (n > 110.0 && n <= 210) {
		p = 110 * 0.5 + (n - 110.0) * 0.55;
		m = 'B';
		s = n - 110.0;
	} else {
		p = 110 * 0.5 + 100 * 0.55 + (n - 210.0) * 0.70;
		m = 'C';
		s = n - 210.0;
	}
	printf("%.2f %c %.2f", p, m, s);
	return 0;
}