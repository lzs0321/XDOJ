#include <stdio.h>

typedef struct {
	char name[20];
	int total;
	int extra;
} ST_INFO;

int compare(ST_INFO st1, ST_INFO st2) {
	if (st1.total == st2.total) {
		return st1.extra - st2.extra;
	}
	return st1.total - st2.total;
}

int main() {
	int n, i, j, k;
	ST_INFO sts[100] = {0};
	scanf("%d", &n);
	for (i = 0; i < n; i++) {
		int s[5], j;
		scanf("%s", sts[i].name);
		for (j = 0; j < 5; j++) {
			scanf("%d", &s[j]);
			sts[i].total += s[j];
		}
		scanf("%d", &sts[i].extra);
		sts[i].total += sts[i].extra;
	}
	for (i = 0; i < n - 1; i++) {
		k = i;
		for (j = i + 1; j < n; j++) {
			if (compare(sts[k], sts[j]) < 0)
				k = j;
		}
		if (k != j) {
			ST_INFO t = sts[i];
			sts[i] = sts[k];
			sts[k] = t;
		}
	}
	for (i = 0; i < n; i++) {
		printf("%s %d %d\n", sts[i].name, sts[i].total, sts[i].extra);

	}
	return 0;
}