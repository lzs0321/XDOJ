#include <stdio.h>

int main() {
	char a[101];
	int sum = 0;
	scanf("%s", &a);
	for (int i = 0; a[i] != '\0'; i++) {
		sum += a[i];
	}
	printf("%d", sum & 0xFF);
	return 0;
}


