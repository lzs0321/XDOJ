#include <stdio.h>
#include <math.h>

int main() {
	int n, m, b;
	scanf("%d", &n);
	m = sqrt(n);
	b = pow(m, 2);
	if (n == b) {
		printf("%d", m);
	} else
		printf("no");
	return 0;
}